package com.capgemini.feedbackmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


class FeedbackManagementSystemApplicationTests {

	void contextLoads() {
	}

}
