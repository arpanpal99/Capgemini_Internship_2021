package com.cg.bookstore.entities;

public class Address {

	private int addressId;
	private String address;
	private String city;
	private String country;
	private String pincode;

}
