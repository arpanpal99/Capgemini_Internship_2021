package com.cg.bookstore.entities;

public class Category {

	private int categoryId;
	private String categoryName;
	
}
