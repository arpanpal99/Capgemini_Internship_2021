package com.cg.bookstore.entities;

public class User {
	private int userId;
	private String email;
	private String password;
	private String role;
}
