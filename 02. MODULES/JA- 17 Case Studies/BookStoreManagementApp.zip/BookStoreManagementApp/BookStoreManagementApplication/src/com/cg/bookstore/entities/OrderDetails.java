package com.cg.bookstore.entities;

public class OrderDetails {

	private Book book;
	private BookOrder bookOrder;
	private int quantity;
	private double subtotal;
	
}
