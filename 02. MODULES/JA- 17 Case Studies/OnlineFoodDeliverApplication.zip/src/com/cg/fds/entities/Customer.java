package com.cg.fds.entities;

public class Customer {

	private String customerId;
	private String firstName;
	private String lastName;
	private String gender;
	private String age;
	private String mobileNumber;
	private Address address;
	private String email;
}
