package com.cg.fds.entities;

public class Category {

	private String catId;
	private String categoryName;
}
