package com.cg.fds.entities;

import java.util.List;

public class FoodCart {

	private String cartId;
	private Customer customer;
	private List<Item> itemList;
}
