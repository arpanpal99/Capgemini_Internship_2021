package com.cg.fds.entities;

public class Address {

	private String addressId;
	private String buildingName;
	private String area;
	private String streetNo;
	private String city;
	private String state;
	private String country;
	private String pincode;
}
