package com.cg.fds.entities;

import java.util.List;

public class Restaurant {
private String restaurantId;
private String restaurantName;
private Address address;
private List<Item> itemList;
private String managerName;
private String contactNumber;

}
