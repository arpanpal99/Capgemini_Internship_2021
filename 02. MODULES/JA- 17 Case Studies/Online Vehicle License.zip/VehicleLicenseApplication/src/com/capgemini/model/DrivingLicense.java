package com.capgemini.model;

import java.util.Date;

public class DrivingLicense {
	private String drivingLicenseNumber;
	private Application application;
	private Date dateOfIssue;
	private Date validTill;
	private RTOOffice issuedBy;
}
