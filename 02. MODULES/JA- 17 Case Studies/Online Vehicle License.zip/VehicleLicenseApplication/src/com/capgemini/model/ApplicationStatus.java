package com.capgemini.model;

public enum ApplicationStatus {
	PENDING, APPROVED, REJECTED
}
