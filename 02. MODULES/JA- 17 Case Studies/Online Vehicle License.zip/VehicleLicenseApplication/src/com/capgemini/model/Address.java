package com.capgemini.model;

public class Address {
	private String state;
	private String city;
	private String house;
	private String landmark;
	private String pincode;
	
	
}
