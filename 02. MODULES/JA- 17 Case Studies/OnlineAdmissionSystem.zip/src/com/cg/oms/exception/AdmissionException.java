package com.cg.oms.exception;

public class AdmissionException {

}
