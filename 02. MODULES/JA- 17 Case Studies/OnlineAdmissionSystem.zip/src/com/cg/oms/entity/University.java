package com.cg.oms.entity;

import java.util.ArrayList;

public class University 
{
	private String name;
	private int universityId;
	private Address address;
	private ArrayList<College> collgeList;
}
