package com.cg.oms.entity;

public class Document
{
private int documentId;
private String documentName;
private String documentUrl;
private int applicantId;
private String emailId;
private String documentStatus;//Uploaded/NotUploaded
}
