package com.cg.oms.entity;

public class User
{
	private String userId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String email;
	private String mobileNumber;
	private String aadharCardNo;
	
	
}
