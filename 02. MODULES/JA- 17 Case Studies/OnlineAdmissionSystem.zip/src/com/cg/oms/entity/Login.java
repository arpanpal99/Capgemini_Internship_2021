package com.cg.oms.entity;

public class Login 
{
	private String userId;
	private String password;
	private String role;

}
