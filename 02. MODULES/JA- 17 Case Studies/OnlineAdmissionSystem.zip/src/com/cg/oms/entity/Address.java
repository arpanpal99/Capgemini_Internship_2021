package com.cg.oms.entity;

public class Address 
{
	private int addressId;
	private String city;
	private String district;
	private  String state;
	private String country;
	private String zipcode;
	private String landmark;
}
