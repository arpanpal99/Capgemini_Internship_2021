package com.cg.oms.entity;
import java.time.LocalDate;
public class ProgramScheduled 
{
	private int scheduleId;	
	private Branch branch;
	private Course course;
	private Program program;
	private College college;
	private University university;	
	private LocalDate startDate;
	private LocalDate endDate;	
}
